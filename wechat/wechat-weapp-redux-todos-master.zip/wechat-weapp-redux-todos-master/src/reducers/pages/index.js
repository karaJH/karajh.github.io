import { Redux } from '../../libs/index';
import projects from './projects';

export default Redux.combineReducers({
  projects,
});
